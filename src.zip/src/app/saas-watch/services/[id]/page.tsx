import Link from "next/link";
import { notFound } from "next/navigation";
import { AppShell, Card, PageHeader } from "@/components/app-shell";
import { ServiceWatchToggle } from "@/components/service-watch-toggle";
import { requireVerifiedUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { serviceMasterIdSchema } from "@/lib/service-master-id";

const newsDateFormatter = new Intl.DateTimeFormat("ja-JP", { dateStyle: "medium" });
export const metadata = { robots: { index: false, follow: false } };

export default async function ServiceDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireVerifiedUser();
  const id = (await params).id;
  if (!serviceMasterIdSchema.safeParse(id).success) notFound();
  const service = await prisma.serviceMaster.findFirst({
    where: { id, status: "ACTIVE" },
    include: {
      watchlistItems: { where: { userId: user.id }, select: { id: true } },
      subscriptions: { where: { userId: user.id, status: "ACTIVE", deletedAt: null }, select: { id: true } },
      newsItems: { where: { sourceType: { in: ["OFFICIAL_RSS", "JAPAN_NEWS_RSS"] } }, orderBy: [{ publishedAt: "desc" }, { fetchedAt: "desc" }], take: 10, select: { id: true, title: true, summaryBase: true, sourceUrl: true, sourceName: true, publishedAt: true, trustLevel: true } },
      priceSnapshots: { where: { trustLevel: "OFFICIAL" }, orderBy: { fetchedAt: "desc" }, take: 60, select: { id: true, planName: true, billingCycle: true, currency: true, amount: true, taxIncluded: true, sourceUrl: true, fetchedAt: true, effectiveAt: true } },
    },
  });
  if (!service) notFound();
  const contracted = service.subscriptions.length > 0;
  const watched = service.watchlistItems.length > 0;
  return <AppShell>
    <PageHeader title={service.name} description={`${service.category}のサービス情報と、契約判断に役立つ公式更新を確認します。`} action={<Link href="/saas-watch" className="btn-secondary">一覧へ戻る</Link>} />
    <div className="grid gap-5 lg:grid-cols-[0.8fr_1.2fr]">
      <Card><p className="text-xs font-black text-blue-700">{service.category}</p><h2 className="mt-2 text-2xl font-black">{service.name}</h2><div className="mt-5 flex flex-wrap gap-2"><a href={service.officialUrl} target="_blank" rel="noreferrer" className="btn-secondary">公式サイト</a>{service.pricingUrl && <a href={service.pricingUrl} target="_blank" rel="noreferrer" className="btn-secondary">料金ページ</a>}{service.newsUrl && <a href={service.newsUrl} target="_blank" rel="noreferrer" className="btn-secondary">公式ニュース</a>}</div><div className="mt-5 rounded-lg bg-slate-50 p-4 text-sm leading-6 text-slate-700">{contracted ? "契約中のサービスです。重要な更新は契約ニュースにも表示します。" : watched ? "ウォッチ中です。価格・プラン・ニュースの更新を確認します。" : "ウォッチすると、価格・プラン・ニュースの更新を確認できます。"}</div>{!contracted && <div className="mt-4"><ServiceWatchToggle serviceId={service.id} watching={watched} /></div>}</Card>
      <div className="space-y-5"><Card><div className="flex items-center justify-between gap-3"><div><h2 className="text-lg font-black">公式価格の履歴</h2><p className="mt-1 text-sm text-slate-600">公式ページから確認できた価格だけを時系列で表示しています。</p></div><span className="text-sm font-bold text-slate-500">{service.priceSnapshots.length}件</span></div>{service.priceSnapshots.length === 0 ? <p className="mt-5 rounded-lg bg-slate-50 p-4 text-sm font-semibold text-slate-600">価格履歴はまだありません。</p> : <div className="mt-4 overflow-x-auto"><table className="min-w-full text-left text-sm"><thead className="border-b border-slate-200 text-xs font-black text-slate-500"><tr><th className="px-2 py-2">プラン</th><th className="px-2 py-2">確認日</th><th className="px-2 py-2">料金</th><th className="px-2 py-2">周期</th><th className="px-2 py-2">出典</th></tr></thead><tbody className="divide-y divide-slate-100">{service.priceSnapshots.map((item) => <tr key={item.id}><td className="whitespace-nowrap px-2 py-3 font-bold">{item.planName}<span className="ml-1 text-xs font-semibold text-slate-500">{item.taxIncluded === true ? "税込" : item.taxIncluded === false ? "税別" : "税区分未確認"}</span></td><td className="whitespace-nowrap px-2 py-3 text-slate-600">{newsDateFormatter.format(item.effectiveAt ?? item.fetchedAt)}</td><td className="whitespace-nowrap px-2 py-3 font-black">{item.currency === "JPY" ? `¥${item.amount.toLocaleString("ja-JP")}` : `${item.amount.toLocaleString("ja-JP")} ${item.currency}`}</td><td className="whitespace-nowrap px-2 py-3 text-slate-600">{item.billingCycle === "MONTHLY" ? "月額" : item.billingCycle === "YEARLY" ? "年額" : item.billingCycle}</td><td className="px-2 py-3"><a href={item.sourceUrl} target="_blank" rel="noreferrer" className="font-bold text-blue-700 hover:underline">公式ページ</a></td></tr>)}</tbody></table></div>}</Card><Card><div className="flex items-center justify-between gap-3"><div><h2 className="text-lg font-black">最新の更新</h2><p className="mt-1 text-sm text-slate-600">公式情報を優先して表示しています。</p></div><span className="text-sm font-bold text-slate-500">{service.newsItems.length}件</span></div>{service.newsItems.length === 0 ? <p className="mt-5 rounded-lg bg-slate-50 p-4 text-sm font-semibold text-slate-600">現在表示できる更新はありません。</p> : <div className="mt-4 divide-y divide-slate-100">{service.newsItems.map((item) => <article key={item.id} className="py-4 first:pt-0 last:pb-0"><div className="flex flex-wrap items-center gap-2"><span className="rounded-full bg-blue-50 px-2 py-1 text-xs font-black text-blue-800">{item.trustLevel === "OFFICIAL" ? "公式情報" : "確認済み"}</span><span className="text-xs font-bold text-slate-500">{item.publishedAt ? newsDateFormatter.format(item.publishedAt) : "掲載日未確認"}</span></div><a href={item.sourceUrl} target="_blank" rel="noreferrer" className="mt-2 block font-black text-blue-700 hover:underline">{item.title}</a>{item.summaryBase && <p className="mt-1 text-sm leading-6 text-slate-600">{item.summaryBase}</p>}<p className="mt-2 text-xs font-bold text-slate-500">情報源: {item.sourceName}</p></article>)}</div>}</Card></div>
    </div>
  </AppShell>;
}

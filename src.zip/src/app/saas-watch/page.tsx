import { SaasWatchView } from "@/components/saas-watch-view";

export const metadata = { robots: { index: false, follow: false } };

export default async function SaasWatchPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const params = await searchParams;
  return <SaasWatchView query={params.q} />;
}

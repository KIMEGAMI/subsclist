import bcrypt from "bcryptjs";
import { NextResponse } from "next/server";
import { z } from "zod";
import { clearSession, createVerificationToken, hashToken, setSession } from "@/lib/auth";
import { EMAIL_VERIFICATION_TOKEN_TTL_MS, MAX_EMAIL_LENGTH, MAX_PASSWORD_LENGTH, MAX_USER_NAME_LENGTH, MIN_PASSWORD_LENGTH } from "@/lib/app-constants";
import { authMailKeys, authMailRateLimit, recordAuthMailAttempt, releaseAuthMailAttempt } from "@/lib/auth-mail-rate-limit";
import { assertAuthSecret, assertMailEnv, env, isProtectedAccountEmail } from "@/lib/env";
import { userErrorMessage } from "@/lib/error-messages";
import { sendVerificationEmail } from "@/lib/mail";
import { prisma } from "@/lib/prisma";
import { requestClientIdentifier } from "@/lib/request-client";

const schema = z.object({
  name: z.string().trim().min(1).max(MAX_USER_NAME_LENGTH),
  email: z.string().trim().email().max(MAX_EMAIL_LENGTH),
  password: z.string().min(MIN_PASSWORD_LENGTH).max(MAX_PASSWORD_LENGTH),
  termsAccepted: z.literal(true),
  privacyAccepted: z.literal(true),
});

const initialCategories = [
  ["動画", "#4f46e5"],
  ["音楽", "#ec4899"],
  ["仕事", "#0ea5e9"],
  ["学習", "#22c55e"],
  ["クラウド", "#f59e0b"],
] as const;

async function createTokenAndSend(userId: string, email: string) {
  const token = createVerificationToken();
  const tokenHash = hashToken(token);
  const now = new Date();
  await prisma.$transaction([
    prisma.emailVerificationToken.updateMany({
      where: { userId, usedAt: null },
      data: { usedAt: now },
    }),
    prisma.emailVerificationToken.create({
      data: {
        userId,
        tokenHash,
        expiresAt: new Date(Date.now() + EMAIL_VERIFICATION_TOKEN_TTL_MS),
      },
    }),
  ]);
  try {
    await sendVerificationEmail(email, token);
  } catch (error) {
    await prisma.emailVerificationToken.updateMany({
      where: { userId, tokenHash, usedAt: null },
      data: { usedAt: new Date() },
    });
    throw error;
  }
}

function rateLimitedResponse(retryAfterSeconds: number) {
  return NextResponse.json(
    { message: `認証メールの送信回数が多すぎます。約${Math.ceil(retryAfterSeconds / 60)}分後に、もう一度お試しください。` },
    { status: 429, headers: { "Retry-After": String(retryAfterSeconds) } },
  );
}

export async function POST(request: Request) {
  try {
    assertAuthSecret();
    assertMailEnv();
  } catch (error) {
    return NextResponse.json({ message: userErrorMessage(error, "メール送信設定を確認してください。") }, { status: 500 });
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ message: "入力内容を確認してください。" }, { status: 400 });
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ message: "入力内容、利用規約、プライバシーポリシーへの同意を確認してください。" }, { status: 400 });
  }

  const { name, password } = parsed.data;
  const email = parsed.data.email.toLowerCase();
  if (isProtectedAccountEmail(email)) {
    return NextResponse.json({ message: "このメールアドレスは新規登録に使用できません。" }, { status: 403 });
  }
  const exists = await prisma.user.findUnique({ where: { email } });

  if (exists?.emailVerified) {
    return NextResponse.json({ message: "このメールアドレスは既に登録済みです。ログインしてください。" }, { status: 409 });
  }

  if (exists && !exists.emailVerified) {
    const keys = authMailKeys(exists.email, requestClientIdentifier(request), env.authSecret);
    const rateLimit = authMailRateLimit(keys);
    if (rateLimit.limited) return rateLimitedResponse(rateLimit.retryAfterSeconds);

    const attemptedAt = Date.now();
    recordAuthMailAttempt(keys, attemptedAt);
    try {
      await createTokenAndSend(exists.id, exists.email);
      await clearSession();
      return NextResponse.json({
        ok: true,
        alreadyRegistered: true,
        message: "このメールアドレスは登録済みですが、メール認証が未完了です。認証メールを再送しました。",
      });
    } catch {
      releaseAuthMailAttempt(keys, attemptedAt);
      console.error("Failed to resend verification email during registration.");
      await clearSession();
      return NextResponse.json(
        {
          message: "このメールアドレスは登録済みですが、認証メールを送信できませんでした。メール送信設定を確認してください。",
          alreadyRegistered: true,
          mailSent: false,
        },
        { status: 500 },
      );
    }
  }

  const keys = authMailKeys(email, requestClientIdentifier(request), env.authSecret);
  const rateLimit = authMailRateLimit(keys);
  if (rateLimit.limited) return rateLimitedResponse(rateLimit.retryAfterSeconds);

  const passwordHash = await bcrypt.hash(password, 12);
  const token = createVerificationToken();
  const tokenHash = hashToken(token);

  const user = await prisma.user.create({
    data: {
      name,
      email,
      passwordHash,
      categories: {
        create: initialCategories.map(([categoryName, color]) => ({
          name: categoryName,
          color,
        })),
      },
      emailVerificationTokens: {
        create: {
          tokenHash,
          expiresAt: new Date(Date.now() + EMAIL_VERIFICATION_TOKEN_TTL_MS),
        },
      },
    },
  });

  const attemptedAt = Date.now();
  recordAuthMailAttempt(keys, attemptedAt);
  try {
    await sendVerificationEmail(email, token);
  } catch {
    releaseAuthMailAttempt(keys, attemptedAt);
    console.error("Failed to send verification email after registration.");
    await setSession(user.id, false);
    return NextResponse.json(
      {
        message: "登録は完了しましたが、認証メールを送信できませんでした。メール送信設定を確認してから、メール認証画面で再送してください。",
        registered: true,
        mailSent: false,
      },
      { status: 202 },
    );
  }

  await setSession(user.id, false);
  return NextResponse.json({ ok: true, mailSent: true, message: "登録が完了しました。認証メールを送信しました。" });
}

import { NextResponse } from "next/server";
import { getVerifiedApiUser } from "@/lib/api-auth";
import { accessibleNewsServiceIds } from "@/lib/news-access";
import { isNewsManualSyncRateLimited } from "@/lib/news-manual-sync-rate-limit";
import { syncOfficialNewsFeeds } from "@/lib/official-news-sync";
import { prisma } from "@/lib/prisma";

export async function POST() {
  const access = await getVerifiedApiUser();
  if (!access.ok) return access.response;
  if (isNewsManualSyncRateLimited(access.user.id)) {
    return NextResponse.json(
      { message: "短時間に何度も更新できません。1分後にもう一度お試しください。" },
      { status: 429, headers: { "Retry-After": "60" } },
    );
  }

  const [services, subscriptions, watchlist] = await Promise.all([
    prisma.serviceMaster.findMany({ where: { status: "ACTIVE" }, select: { id: true, name: true } }),
    prisma.subscription.findMany({ where: { userId: access.user.id, status: "ACTIVE", deletedAt: null }, select: { name: true, serviceMasterId: true } }),
    prisma.serviceWatchlist.findMany({ where: { userId: access.user.id, watchNews: true }, select: { serviceId: true } }),
  ]);
  const serviceIds = new Set(accessibleNewsServiceIds({ subscriptions, services }));
  for (const item of watchlist) serviceIds.add(item.serviceId);

  const result = await syncOfficialNewsFeeds({ serviceIds: [...serviceIds] });
  return NextResponse.json({ ok: result.failedServices.length === 0, ...result });
}

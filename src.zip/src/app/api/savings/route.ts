import { NextResponse } from "next/server";
import { getVerifiedApiUser } from "@/lib/api-auth";
import { prisma } from "@/lib/prisma";

function monthKey(date: Date) {
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
}

export async function GET() {
  const access = await getVerifiedApiUser();
  if (!access.ok) return access.response;
  const now = new Date();
  const monthStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1));
  const yearStart = new Date(Date.UTC(now.getUTCFullYear(), 0, 1));
  const chartStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 11, 1));
  const events = await prisma.savingsEvent.findMany({
    where: { userId: access.user.id },
    orderBy: { confirmedAt: "desc" },
    take: 100,
    select: { id: true, type: true, beforeMonthlyAmount: true, afterMonthlyAmount: true, monthlySaving: true, annualSaving: true, confirmedAt: true, note: true, subscription: { select: { id: true, name: true } } },
  });
  const months = Array.from({ length: 12 }, (_, index) => new Date(Date.UTC(chartStart.getUTCFullYear(), chartStart.getUTCMonth() + index, 1)));
  return NextResponse.json({
    summary: {
      monthSaving: events.filter((event) => event.confirmedAt >= monthStart).reduce((sum, event) => sum + event.monthlySaving, 0),
      yearSaving: events.filter((event) => event.confirmedAt >= yearStart).reduce((sum, event) => sum + event.monthlySaving, 0),
      lifetimeSaving: events.reduce((sum, event) => sum + event.monthlySaving, 0),
    },
    monthly: months.map((month) => ({ key: monthKey(month), saving: events.filter((event) => monthKey(event.confirmedAt) === monthKey(month)).reduce((sum, event) => sum + event.monthlySaving, 0) })),
    events: events.map((event) => ({ ...event, confirmedAt: event.confirmedAt.toISOString() })),
  }, { headers: { "Cache-Control": "private, no-store" } });
}

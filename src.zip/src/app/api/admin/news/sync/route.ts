import { NextResponse } from "next/server";
import { getAdminApiUser } from "@/lib/api-auth";
import { env } from "@/lib/env";
import { syncOfficialNewsFeeds } from "@/lib/official-news-sync";

export async function POST(request: Request) {
  const cronAuthorized = Boolean(
    env.newsJobSecret
      && request.headers.get("authorization") === `Bearer ${env.newsJobSecret}`,
  );
  const access = cronAuthorized ? null : await getAdminApiUser();
  if (access && !access.ok) return access.response;

  const result = await syncOfficialNewsFeeds();

  return NextResponse.json({
    ok: result.failedServices.length === 0,
    ...result,
  });
}

import { NextResponse } from "next/server";
import { getAdminApiUser } from "@/lib/api-auth";
import { runDailyNewsJob } from "@/lib/daily-news";
import { env } from "@/lib/env";

export async function POST(request: Request) {
  const cronAuthorized = Boolean(
    env.newsJobSecret
      && request.headers.get("authorization") === `Bearer ${env.newsJobSecret}`,
  );
  const access = cronAuthorized ? null : await getAdminApiUser();
  if (access && !access.ok) return access.response;

  try {
    const result = await runDailyNewsJob();
    return NextResponse.json({ ok: result.failedArticleCount === 0, ...result });
  } catch {
    return NextResponse.json(
      { message: "公式ニュースの更新に失敗しました。ニュース情報源とジョブ状態を確認してください。" },
      { status: 503 },
    );
  }
}

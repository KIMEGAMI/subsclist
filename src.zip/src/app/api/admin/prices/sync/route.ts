import { NextResponse } from "next/server";
import { getAdminApiUser } from "@/lib/api-auth";
import { env } from "@/lib/env";
import { syncOfficialServicePrices } from "@/lib/service-price";

export async function POST(request: Request) {
  const jobAuthorized = Boolean(
    env.newsJobSecret && request.headers.get("authorization") === `Bearer ${env.newsJobSecret}`,
  );
  const access = jobAuthorized ? null : await getAdminApiUser();
  if (access && !access.ok) return access.response;
  try {
    const result = await syncOfficialServicePrices();
    return NextResponse.json({ ok: result.failedServices.length === 0, ...result });
  } catch {
    return NextResponse.json({ message: "公式価格の確認に失敗しました。時間を置いて再実行してください。" }, { status: 503 });
  }
}

import { prisma } from "@/lib/prisma";
import { parseOfficialPriceJsonLd } from "@/lib/service-price-parser";

const MAX_RESPONSE_BYTES = 1_000_000;
const FETCH_TIMEOUT_MS = 10_000;

function isAllowedPricingUrl(value: string) {
  try {
    const url = new URL(value);
    if (url.protocol !== "https:") return false;
    if (["localhost", "127.0.0.1", "::1"].includes(url.hostname)) return false;
    if (/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(url.hostname)) return false;
    return true;
  } catch {
    return false;
  }
}

async function fetchPricingPage(url: string) {
  if (!isAllowedPricingUrl(url)) throw new Error("Pricing URL is not allowed");
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), FETCH_TIMEOUT_MS);
  try {
    const response = await fetch(url, { signal: controller.signal, redirect: "error", headers: { Accept: "text/html,application/xhtml+xml" } });
    if (!response.ok) throw new Error(`Pricing page returned ${response.status}`);
    const contentLength = Number(response.headers.get("content-length") ?? "0");
    if (contentLength > MAX_RESPONSE_BYTES) throw new Error("Pricing page is too large");
    const body = await response.text();
    if (new TextEncoder().encode(body).byteLength > MAX_RESPONSE_BYTES) throw new Error("Pricing page is too large");
    return body;
  } finally {
    clearTimeout(timeout);
  }
}

export type OfficialPriceSyncResult = { services: number; snapshots: number; changes: number; failedServices: string[] };

export async function syncOfficialServicePrices(serviceId?: string): Promise<OfficialPriceSyncResult> {
  const services = await prisma.serviceMaster.findMany({
    where: { status: "ACTIVE", pricingUrl: { not: null }, ...(serviceId ? { id: serviceId } : {}) },
    select: { id: true, name: true, pricingUrl: true },
  });
  let snapshots = 0;
  let changes = 0;
  const failedServices: string[] = [];
  for (const service of services) {
    if (!service.pricingUrl) continue;
    try {
      const records = parseOfficialPriceJsonLd(await fetchPricingPage(service.pricingUrl));
      for (const record of records) {
        const previous = await prisma.servicePriceSnapshot.findFirst({ where: { serviceId: service.id, planName: record.planName, currency: record.currency }, orderBy: { fetchedAt: "desc" } });
        if (previous && previous.amount === record.amount && previous.billingCycle === record.billingCycle) continue;
        await prisma.servicePriceSnapshot.create({ data: { serviceId: service.id, ...record, sourceUrl: service.pricingUrl, trustLevel: "OFFICIAL" } });
        snapshots += 1;
        if (previous && previous.amount !== record.amount) {
          await prisma.servicePriceChange.create({ data: { serviceId: service.id, planName: record.planName, oldAmount: previous.amount, newAmount: record.amount, changeAmount: record.amount - previous.amount, changePercent: previous.amount === 0 ? null : ((record.amount - previous.amount) / previous.amount) * 100, currency: record.currency, sourceUrl: service.pricingUrl, verified: true, effectiveAt: record.effectiveAt } });
          changes += 1;
        }
      }
    } catch {
      failedServices.push(service.name);
    }
  }
  return { services: services.length, snapshots, changes, failedServices };
}

import assert from "node:assert/strict";
import test from "node:test";
import { parseOfficialPriceJsonLd } from "./service-price-parser.ts";

test("official JSON-LD pricing is parsed without guessing visible text", () => {
  const html = `<h1>月額 980円</h1><script type="application/ld+json">${JSON.stringify({
    "@type": "Product",
    name: "Premium",
    offers: { price: 980, priceCurrency: "JPY", description: "税込" },
  })}</script>`;
  assert.deepEqual(parseOfficialPriceJsonLd(html), [{
    planName: "Premium",
    billingCycle: "MONTHLY",
    currency: "JPY",
    amount: 980,
    taxIncluded: true,
    effectiveAt: null,
  }]);
});

test("invalid or non-structured pricing is ignored", () => {
  const html = `<p>月額 980円</p><script type="application/ld+json">not-json</script>`;
  assert.deepEqual(parseOfficialPriceJsonLd(html), []);
});

import {
  NEWS_MANUAL_SYNC_RATE_LIMIT_MAX_REQUESTS,
  NEWS_MANUAL_SYNC_RATE_LIMIT_WINDOW_MS,
} from "@/lib/app-constants";

const requests = new Map<string, number[]>();

export function isNewsManualSyncRateLimited(userId: string, now = Date.now()) {
  const recent = (requests.get(userId) ?? []).filter(
    (timestamp) => now - timestamp < NEWS_MANUAL_SYNC_RATE_LIMIT_WINDOW_MS,
  );
  if (recent.length >= NEWS_MANUAL_SYNC_RATE_LIMIT_MAX_REQUESTS) {
    requests.set(userId, recent);
    return true;
  }
  recent.push(now);
  requests.set(userId, recent);
  return false;
}

export function resetNewsManualSyncRateLimitForTests() {
  requests.clear();
}

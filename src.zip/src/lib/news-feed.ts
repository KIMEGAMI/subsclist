import { createHash } from "node:crypto";

const maxFeedBytes = 1_000_000;
const maxFeedItems = 30;
const maxTitleLength = 300;
const maxSummaryLength = 2_000;
const allowedContentTypes = ["application/atom+xml", "application/rss+xml", "application/xml", "text/xml"];
const blockedHostnamePattern = /(^|\.)(localhost|local)$/i;
const ipv4HostnamePattern = /^(?:\d{1,3}\.){3}\d{1,3}$/;
const ipv6HostnamePattern = /^\[[0-9a-f:]+\]$/i;

export type OfficialNewsFeedItem = {
  title: string;
  summaryBase: string | null;
  sourceUrl: string;
  publishedAt: Date | null;
  category: string;
  contentHash: string;
};

export class OfficialNewsFeedError extends Error {}

function decodeXmlEntities(value: string) {
  return value
    .replace(/&(?:amp|lt|gt|quot|apos|nbsp);/gi, (entity) => ({
      "&amp;": "&",
      "&lt;": "<",
      "&gt;": ">",
      "&quot;": '"',
      "&apos;": "'",
      "&nbsp;": " ",
    })[entity.toLowerCase()] ?? entity)
    .replace(/&#(\d+);/g, (_match, code: string) => String.fromCodePoint(Number(code)))
    .replace(/&#x([\da-f]+);/gi, (_match, code: string) => String.fromCodePoint(Number.parseInt(code, 16)));
}

function decodeXml(value: string) {
  let decoded = value.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1");
  for (let pass = 0; pass < 2; pass += 1) {
    decoded = decodeXmlEntities(decoded).replace(/<[^>]*>/g, " ");
  }
  return decoded.replace(/\s+/g, " ").trim();
}

export function sanitizeNewsText(value: string | null | undefined) {
  return value ? decodeXml(value) : null;
}

function xmlValue(item: string, names: string[]) {
  for (const name of names) {
    const matched = item.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`, "i"));
    if (matched?.[1]) return decodeXml(matched[1]);
  }
  return "";
}

function atomLink(item: string) {
  const matched = item.match(/<link\s+[^>]*href=["']([^"']+)["'][^>]*>/i);
  return matched?.[1]?.trim() ?? "";
}

function validPublishedAt(value: string) {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function bounded(value: string, maximum: number) {
  return value.slice(0, maximum);
}

function hasJapaneseText(value: string) {
  return /[\u3040-\u30ff\u3400-\u9fff]/u.test(value);
}

export function assertOfficialFeedUrl(value: string) {
  let url: URL;
  try {
    url = new URL(value);
  } catch {
    throw new OfficialNewsFeedError("ニュース情報源のURL形式が正しくありません。");
  }
  const hostname = url.hostname.toLowerCase();
  if (
    url.protocol !== "https:"
    || !hostname
    || blockedHostnamePattern.test(hostname)
    || ipv4HostnamePattern.test(hostname)
    || ipv6HostnamePattern.test(hostname)
  ) {
    throw new OfficialNewsFeedError("ニュース情報源として利用できないURLです。");
  }
  return url;
}

export function parseOfficialNewsFeed(xml: string, options?: { requireSummary?: boolean }): OfficialNewsFeedItem[] {
  const items = xml.match(/<(?:item|entry)(?:\s[^>]*)?>[\s\S]*?<\/(?:item|entry)>/gi) ?? [];
  const seen = new Set<string>();
  const parsed: OfficialNewsFeedItem[] = [];

  for (const item of items) {
    if (parsed.length >= maxFeedItems) break;
    const title = bounded(xmlValue(item, ["title"]), maxTitleLength);
    const rawUrl = xmlValue(item, ["link"]) || atomLink(item);
    if (!title || !rawUrl) continue;

    let sourceUrl: URL;
    try {
      sourceUrl = assertOfficialFeedUrl(rawUrl);
    } catch {
      continue;
    }

    const contentHash = createHash("sha256")
      .update(`${sourceUrl.toString()}\n${title}`)
      .digest("hex");
    if (seen.has(contentHash)) continue;
    seen.add(contentHash);
    const summary = bounded(xmlValue(item, ["description", "summary", "content"]), maxSummaryLength);
    // Avoid publishing English-only RSS items when translation quality cannot be verified.
    if (!hasJapaneseText(title) && !hasJapaneseText(summary)) continue;
    if (options?.requireSummary && summary.length < 30) continue;
    parsed.push({
      title,
      summaryBase: summary || null,
      sourceUrl: sourceUrl.toString(),
      publishedAt: validPublishedAt(xmlValue(item, ["pubDate", "published", "updated"])),
      category: bounded(xmlValue(item, ["category"]) || "更新", 50),
      contentHash,
    });
  }
  return parsed;
}

export async function fetchOfficialNewsFeed(feedUrl: string) {
  const url = assertOfficialFeedUrl(feedUrl);
  const response = await fetch(url, {
    headers: { Accept: "application/rss+xml, application/atom+xml, application/xml, text/xml" },
    redirect: "error",
    signal: AbortSignal.timeout(10_000),
    cache: "no-store",
  });
  if (!response.ok) throw new OfficialNewsFeedError("公式ニュースの取得に失敗しました。");
  const contentType = response.headers.get("content-type")?.toLowerCase() ?? "";
  if (!allowedContentTypes.some((type) => contentType.includes(type))) {
    throw new OfficialNewsFeedError("公式ニュースの形式がRSSまたはAtomではありません。");
  }
  const contentLength = Number(response.headers.get("content-length") ?? "0");
  if (Number.isFinite(contentLength) && contentLength > maxFeedBytes) {
    throw new OfficialNewsFeedError("公式ニュースのサイズが上限を超えています。");
  }
  const text = await response.text();
  if (Buffer.byteLength(text, "utf8") > maxFeedBytes) {
    throw new OfficialNewsFeedError("公式ニュースのサイズが上限を超えています。");
  }
  return parseOfficialNewsFeed(text, { requireSummary: url.hostname === "news.google.com" });
}

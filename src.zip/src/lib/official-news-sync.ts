import { fetchOfficialNewsFeed } from "@/lib/news-feed";
import { NEWS_MAX_ITEMS_PER_DAY } from "@/lib/app-constants";
import { prisma } from "@/lib/prisma";

function isRssOrAtomFeedUrl(value: string) {
  try {
    const url = new URL(value);
    return url.hostname === "news.google.com"
      || url.pathname.endsWith("/feed/")
      || url.pathname.endsWith("/feed")
      || url.pathname.endsWith("/rss/")
      || url.pathname.endsWith("/rss")
      || url.pathname.endsWith(".xml");
  } catch {
    return false;
  }
}

export type OfficialNewsSyncResult = {
  imported: number;
  failedServices: string[];
};

type PendingNewsItem = {
  serviceId: string;
  sourceName: string;
  sourceType: "OFFICIAL_RSS" | "JAPAN_NEWS_RSS";
  trustLevel: "OFFICIAL" | "VERIFIED";
  item: Awaited<ReturnType<typeof fetchOfficialNewsFeed>>[number];
};

function japaneseNewsFeedUrl(serviceName: string) {
  const query = `${serviceName} (料金 OR プラン OR 値上げ OR 障害 OR 終了 OR 仕様変更)`;
  return `https://news.google.com/rss/search?q=${encodeURIComponent(query)}&hl=ja&gl=JP&ceid=JP:ja`;
}

function japanDayStart(now = new Date()) {
  const parts = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Tokyo", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(now);
  const values = new Map(parts.map((part) => [part.type, part.value]));
  return new Date(`${values.get("year")}-${values.get("month")}-${values.get("day")}T00:00:00+09:00`);
}

export async function syncOfficialNewsFeeds(options?: { serviceIds?: string[] }): Promise<OfficialNewsSyncResult> {
  const services = await prisma.serviceMaster.findMany({
    where: {
      status: "ACTIVE",
      ...(options?.serviceIds ? { id: { in: options.serviceIds } } : {}),
    },
    select: { id: true, name: true, newsUrl: true },
  });
  let imported = 0;
  const failedServices: string[] = [];
  const pendingItems: PendingNewsItem[] = [];

  for (const service of services) {
    const feedSources: Array<{
      url: string;
      sourceType: PendingNewsItem["sourceType"];
      sourceName: string;
      trustLevel: PendingNewsItem["trustLevel"];
    }> = [
      service.newsUrl && isRssOrAtomFeedUrl(service.newsUrl)
        ? { url: service.newsUrl, sourceType: "OFFICIAL_RSS" as const, sourceName: service.name, trustLevel: "OFFICIAL" as const }
        : null,
      { url: japaneseNewsFeedUrl(service.name), sourceType: "JAPAN_NEWS_RSS" as const, sourceName: `${service.name}（日本語ニュース）`, trustLevel: "VERIFIED" as const },
    ].filter((source): source is NonNullable<typeof source> => source !== null);
    for (const source of feedSources) {
      try {
        const items = await fetchOfficialNewsFeed(source.url);
        pendingItems.push(...items.map((item) => ({ serviceId: service.id, sourceName: source.sourceName, sourceType: source.sourceType, trustLevel: source.trustLevel, item })));
      } catch {
        failedServices.push(source.sourceName);
        console.error("News feed sync failed.");
      }
    }
  }

  const uniquePendingItems = [...new Map(pendingItems.map((pending) => [pending.item.contentHash, pending])).values()];
  uniquePendingItems.sort((left, right) => (right.item.publishedAt?.getTime() ?? 0) - (left.item.publishedAt?.getTime() ?? 0));
  const existingHashes = new Set((await prisma.newsItem.findMany({ where: { contentHash: { in: uniquePendingItems.map((pending) => pending.item.contentHash) } }, select: { contentHash: true } })).map((item) => item.contentHash));
  const todayCount = await prisma.newsItem.count({ where: { fetchedAt: { gte: japanDayStart() }, sourceType: { in: ["OFFICIAL_RSS", "JAPAN_NEWS_RSS"] } } });
  const remainingToday = Math.max(0, NEWS_MAX_ITEMS_PER_DAY - todayCount);
  for (const pending of uniquePendingItems.filter((item) => !existingHashes.has(item.item.contentHash)).slice(0, remainingToday)) {
    await prisma.newsItem.upsert({
      where: { contentHash: pending.item.contentHash },
      create: {
        serviceId: pending.serviceId,
        title: pending.item.title,
        summaryBase: pending.item.summaryBase,
        sourceUrl: pending.item.sourceUrl,
        sourceName: pending.sourceName,
        sourceType: pending.sourceType,
        publishedAt: pending.item.publishedAt,
        category: pending.item.category,
        importance: 0,
        trustLevel: pending.trustLevel,
        contentHash: pending.item.contentHash,
      },
      update: {},
    });
    imported += 1;
  }

  return { imported, failedServices };
}
